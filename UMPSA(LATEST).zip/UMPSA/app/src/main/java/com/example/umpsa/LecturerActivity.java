package com.example.umpsa;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.core.graphics.ColorUtils;

public class LecturerActivity extends Activity {

    private ViewFlipper viewFlipper;
    private Button btnNavReport, btnNavManage, btnNavProfile, btnCreateQuiz, btnPublishQuiz,
            btnCreateAssignment, btnPublishAssignment, btnSendChat, btnUploadFile, btnSave;
    private TextView btnBackFromQuiz, btnBackFromAssignment, btnBackFromStudent, btnBackFromChat,
            btnFloatingAi, btnViewDetails;
    private EditText etQuizTitle, etQuizDueDate, etAssignmentTitle, etAssignmentDueDate, etChatMessage;
    private Switch switchHidden, switchAssignmentHidden, switchModifyHidden;
    private LinearLayout containerActivities, chatMessageContainer, btnHciQuizDetails;
    private ScrollView chatScrollView;
    private TextView tvFileName;
    private LinearLayout lastClickedItem;

    @SuppressLint({"MissingInflatedId", "SetTextI18n", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActionBar() != null) getActionBar().hide();
        setContentView(R.layout.activity_lecturer);

        // Map UI Elements
        viewFlipper = findViewById(R.id.viewFlipper);
        btnNavReport = findViewById(R.id.btnNavReport);
        btnNavManage = findViewById(R.id.btnNavManage);
        containerActivities = findViewById(R.id.containerActivities);
        btnNavProfile = findViewById(R.id.btnNavProfile);
        btnViewDetails = findViewById(R.id.btnViewDetails);
        btnBackFromStudent = findViewById(R.id.btnBackFromStudent);

        // Quiz Elements
        btnCreateQuiz = findViewById(R.id.btnCreateQuiz);
        btnBackFromQuiz = findViewById(R.id.btnBackFromQuiz);
        btnPublishQuiz = findViewById(R.id.btnPublishQuiz);
        etQuizTitle = findViewById(R.id.etQuizTitle);
        etQuizDueDate = findViewById(R.id.etQuizDueDate);
        switchHidden = findViewById(R.id.switchHidden);
        btnHciQuizDetails = findViewById(R.id.btnHciQuizDetails);
        switchModifyHidden = findViewById(R.id.switchModifyHidden);

        // Assignment Elements
        btnCreateAssignment = findViewById(R.id.btnCreateAssignment);
        btnBackFromAssignment = findViewById(R.id.btnBackFromAssignment);
        btnPublishAssignment = findViewById(R.id.btnPublishAssignment);
        etAssignmentTitle = findViewById(R.id.etAssignmentTitle);
        etAssignmentDueDate = findViewById(R.id.etAssignmentDueDate);
        switchAssignmentHidden = findViewById(R.id.switchAssignmentHidden);
        btnUploadFile = findViewById(R.id.btnUploadFile);
        tvFileName = findViewById(R.id.tvFileName);

        // ChatBot Elements
        btnFloatingAi = findViewById(R.id.btnFloatingAi);
        btnBackFromChat = findViewById(R.id.btnBackFromChat);
        btnSendChat = findViewById(R.id.btnSendChat);
        etChatMessage = findViewById(R.id.etChatMessage);
        chatMessageContainer = findViewById(R.id.chatMessageContainer);
        chatScrollView = findViewById(R.id.chatScrollView);

        btnSave = findViewById(R.id.button3);

        setupNavigation();
        setupQuizButtons();
        setupAssignmentButtons();
        setupChatButtons();
    }

    private void setupNavigation() {
        btnNavReport.setOnClickListener(v -> { viewFlipper.setDisplayedChild(0); updateNavState(0); });
        btnNavManage.setOnClickListener(v -> { viewFlipper.setDisplayedChild(1); updateNavState(1); });
        btnNavProfile.setOnClickListener(v -> { viewFlipper.setDisplayedChild(5); updateNavState(2); btnFloatingAi.setVisibility(View.VISIBLE); });
        btnViewDetails.setOnClickListener(v -> { viewFlipper.setDisplayedChild(6); btnFloatingAi.setVisibility(View.GONE); });
        btnBackFromStudent.setOnClickListener(v -> { viewFlipper.setDisplayedChild(0); btnFloatingAi.setVisibility(View.VISIBLE); });

        btnHciQuizDetails.setOnClickListener(v -> {
            lastClickedItem = btnHciQuizDetails;
            viewFlipper.setDisplayedChild(7);
            btnFloatingAi.setVisibility(View.GONE);
            deselectBottomNav();
        });
    }

    private void setupQuizButtons() {
        TextView btnBackFromModify = findViewById(R.id.btnBack);
        btnBackFromModify.setOnClickListener(v -> {
            viewFlipper.setDisplayedChild(1);
            btnFloatingAi.setVisibility(View.VISIBLE);
            updateNavState(1);
        });

        btnSave.setOnClickListener(v -> saveModifiedQuiz());

        btnCreateQuiz.setOnClickListener(v -> {
            viewFlipper.setDisplayedChild(2);
            etQuizTitle.getText().clear();
            etQuizDueDate.getText().clear();
            deselectBottomNav();
        });

        btnBackFromQuiz.setOnClickListener(v -> { viewFlipper.setDisplayedChild(1); updateNavState(1); });
        btnPublishQuiz.setOnClickListener(v -> publishQuiz());
    }

    private void setupAssignmentButtons() {
        btnCreateAssignment.setOnClickListener(v -> {
            viewFlipper.setDisplayedChild(3);
            etAssignmentTitle.getText().clear();
            etAssignmentDueDate.getText().clear();
            tvFileName.setText("No file selected");
            tvFileName.setTextColor(Color.parseColor("#6B7280"));
            switchAssignmentHidden.setChecked(false);
            deselectBottomNav();
        });

        btnBackFromAssignment.setOnClickListener(v -> { viewFlipper.setDisplayedChild(1); updateNavState(1); });
        btnUploadFile.setOnClickListener(v -> {
            tvFileName.setText("rubric_BCS2173_final.pdf");
            tvFileName.setTextColor(Color.parseColor("#10B981"));
            Toast.makeText(this, "File Attached Successfully", Toast.LENGTH_SHORT).show();
        });

        btnPublishAssignment.setOnClickListener(v -> publishAssignment());
    }

    private void setupChatButtons() {
        btnFloatingAi.setOnTouchListener(this::handleFloatingAiTouch);

        btnBackFromChat.setOnClickListener(v -> {
            viewFlipper.setDisplayedChild(1);
            btnFloatingAi.setVisibility(View.VISIBLE);
            updateNavState(1);
        });

        btnSendChat.setOnClickListener(v -> handleSendChat());
    }

    private void updateNavState(int tabIndex) {
        btnNavReport.setBackgroundColor(Color.TRANSPARENT);
        btnNavManage.setBackgroundColor(Color.TRANSPARENT);
        btnNavProfile.setBackgroundColor(Color.TRANSPARENT);

        if(tabIndex == 0) btnNavReport.setBackgroundResource(R.drawable.nav_selected);
        else if(tabIndex == 1) btnNavManage.setBackgroundResource(R.drawable.nav_selected);
        else if(tabIndex == 2) btnNavProfile.setBackgroundResource(R.drawable.nav_selected);
    }

    private void deselectBottomNav() {
        btnNavReport.setBackgroundColor(Color.TRANSPARENT);
        btnNavManage.setBackgroundColor(Color.TRANSPARENT);
        btnNavProfile.setBackgroundColor(Color.TRANSPARENT);
    }

    private void publishQuiz() {
        String title = etQuizTitle.getText().toString().trim();
        String dueDate = etQuizDueDate.getText().toString().trim();
        if (title.isEmpty()) { Toast.makeText(this, "Enter quiz title", Toast.LENGTH_SHORT).show(); return; }

        LinearLayout card = createQuizCard(title, dueDate);
        containerActivities.addView(card);

        etQuizTitle.setText("");
        etQuizDueDate.setText("");
        Toast.makeText(this,"Quiz published successfully!",Toast.LENGTH_SHORT).show();
    }

    private LinearLayout createQuizCard(String title, String dueDate) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 8, 0, 0);
        card.setLayoutParams(cardParams);
        card.setPadding(16,16,16,16);
        card.setBackgroundResource(R.drawable.card_white_big);
        card.setElevation(2f);

        TextView icon = new TextView(this);
        icon.setText(dueDate.isEmpty() ? "🔒" : "📄");
        icon.setTextSize(28f);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(56,56);
        iconParams.setMargins(0,0,16,0);
        icon.setLayoutParams(iconParams);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1f);
        info.setLayoutParams(infoParams);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setTextSize(16f);
        tvTitle.setTextColor(Color.BLACK);
        info.addView(tvTitle);

        TextView tvDeadline = new TextView(this);
        tvDeadline.setText(dueDate.isEmpty() ? "Draft (hidden from students)" : "Closes " + dueDate);
        tvDeadline.setTextSize(12f);
        tvDeadline.setTextColor(Color.GRAY);
        info.addView(tvDeadline);

        card.addView(info);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(28f);
        LinearLayout.LayoutParams arrowParams = new LinearLayout.LayoutParams(56,56);
        arrow.setLayoutParams(arrowParams);
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow);

        card.setTag(new String[]{title, dueDate});

        card.setOnClickListener(v -> {
            lastClickedItem = card;
            viewFlipper.setDisplayedChild(7);
            deselectBottomNav();
            btnFloatingAi.setVisibility(View.GONE);

            String[] data = (String[]) card.getTag();
            etQuizTitle.setText(data[0]);
            etQuizDueDate.setText(data[1]);
            switchModifyHidden.setChecked(data[1].isEmpty());
        });

        return card;
    }

    private void saveModifiedQuiz() {
        if(lastClickedItem == null) return;

        String updatedTitle = etQuizTitle.getText().toString();
        String updatedDueDate = etQuizDueDate.getText().toString();
        boolean isHidden = switchModifyHidden.isChecked();

        LinearLayout infoLayout = (LinearLayout) lastClickedItem.getChildAt(1);
        TextView tvTitle = (TextView) infoLayout.getChildAt(0);
        TextView tvDeadline = (TextView) infoLayout.getChildAt(1);

        tvTitle.setText(updatedTitle);
        tvDeadline.setText(isHidden ? "Draft (Hidden from students)" : "Closes " + updatedDueDate);

        lastClickedItem.setTag(new String[]{updatedTitle, updatedDueDate});

        Toast.makeText(this,"Quiz updated!",Toast.LENGTH_SHORT).show();
        viewFlipper.setDisplayedChild(1);
        btnFloatingAi.setVisibility(View.VISIBLE);
    }

    private void publishAssignment() {
        String title = etAssignmentTitle.getText().toString().trim();
        String dueDate = etAssignmentDueDate.getText().toString().trim();
        if(title.isEmpty()) { Toast.makeText(this,"Enter assignment title",Toast.LENGTH_SHORT).show(); return; }

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0,8,0,0);
        card.setLayoutParams(cardParams);
        card.setPadding(16,16,16,16);
        card.setBackgroundResource(R.drawable.card_white_big);
        card.setElevation(2f);

        TextView icon = new TextView(this);
        icon.setText("📄");
        icon.setTextSize(28f);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(56,56);
        iconParams.setMargins(0,0,16,0);
        icon.setLayoutParams(iconParams);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1f);
        info.setLayoutParams(infoParams);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setTextSize(16f);
        tvTitle.setTextColor(Color.BLACK);
        info.addView(tvTitle);

        TextView tvDeadline = new TextView(this);
        tvDeadline.setText(dueDate.isEmpty() ? "Draft" : "Closes " + dueDate);
        tvDeadline.setTextSize(12f);
        tvDeadline.setTextColor(Color.GRAY);
        info.addView(tvDeadline);

        card.addView(info);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(28f);
        LinearLayout.LayoutParams arrowParams = new LinearLayout.LayoutParams(56,56);
        arrow.setLayoutParams(arrowParams);
        arrow.setGravity(Gravity.CENTER);
        card.addView(arrow);

        containerActivities.addView(card);
        etAssignmentTitle.setText("");
        etAssignmentDueDate.setText("");
        Toast.makeText(this,"Assignment published successfully!",Toast.LENGTH_SHORT).show();
    }

    private boolean handleFloatingAiTouch(View view, MotionEvent event) {
        float dX=0f,dY=0f,initialX=0f,initialY=0f;
        switch (event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                dX=view.getX()-event.getRawX();
                dY=view.getY()-event.getRawY();
                initialX=event.getRawX();
                initialY=event.getRawY();
                return true;
            case MotionEvent.ACTION_MOVE:
                view.animate().x(event.getRawX()+dX).y(event.getRawY()+dY).setDuration(0).start();
                return true;
            case MotionEvent.ACTION_UP:
                float diffX=Math.abs(event.getRawX()-initialX);
                float diffY=Math.abs(event.getRawY()-initialY);
                if(diffX<10 && diffY<10){
                    viewFlipper.setDisplayedChild(4);
                    btnFloatingAi.setVisibility(View.GONE);
                    deselectBottomNav();
                }
                return true;
            default: return false;
        }
    }

    private void handleSendChat() {
        String message = etChatMessage.getText().toString().trim();
        if(message.isEmpty()) return;

        TextView userMessage = new TextView(this);
        userMessage.setText("You: " + message);
        userMessage.setBackgroundColor(ColorUtils.setAlphaComponent(Color.BLUE,50));
        userMessage.setPadding(12,12,12,12);
        chatMessageContainer.addView(userMessage);
        etChatMessage.setText("");

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            TextView aiMessage = new TextView(this);
            aiMessage.setText("AI: Received your message: "+message);
            aiMessage.setBackgroundColor(ColorUtils.setAlphaComponent(Color.GRAY,50));
            aiMessage.setPadding(12,12,12,12);
            chatMessageContainer.addView(aiMessage);
            chatScrollView.post(() -> chatScrollView.fullScroll(View.FOCUS_DOWN));
        },1000);
    }
}