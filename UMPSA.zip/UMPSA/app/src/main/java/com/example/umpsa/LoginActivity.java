package com.example.umpsa;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {

    EditText editEmail, editPassword;
    RadioButton radioStudent, radioTeacher;
    TextView btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
        radioStudent = findViewById(R.id.radioStudent);
        radioTeacher = findViewById(R.id.radioTeacher);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {
            String email = editEmail.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (email.isEmpty()) {
                Toast.makeText(this, "Please enter education email", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!email.contains(".edu")) {
                Toast.makeText(this, "Please use an education email", Toast.LENGTH_SHORT).show();
                return;
            }

            if (password.isEmpty()) {
                Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
                return;
            }

            String role = radioStudent.isChecked() ? "Student" : "Teacher";

            Toast.makeText(this, "Login as " + role, Toast.LENGTH_SHORT).show();

            // Launch the correct activity based on role
            Intent intent;
            if (role.equals("Teacher")) {
                intent = new Intent(LoginActivity.this, LecturerActivity.class); // Lecturer activity
            } else {
                intent = new Intent(LoginActivity.this, MainActivity.class); // Student activity
            }

            startActivity(intent);
            finish();
        });
    }
}